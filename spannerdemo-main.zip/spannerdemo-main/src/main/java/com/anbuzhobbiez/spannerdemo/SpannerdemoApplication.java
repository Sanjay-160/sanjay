package com.anbuzhobbiez.spannerdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpannerdemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpannerdemoApplication.class, args);
	}

}
