package com.anbuzhobbiez.spannerdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpannerdemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
